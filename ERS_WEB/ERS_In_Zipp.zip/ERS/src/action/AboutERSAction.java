package action;

import com.opensymphony.xwork2.ActionSupport;

public class AboutERSAction extends ActionSupport
{
	private static final long serialVersionUID = -7255166362321379496L;

	public String execute() throws Exception 
	{
		return SUCCESS;
	}
}
