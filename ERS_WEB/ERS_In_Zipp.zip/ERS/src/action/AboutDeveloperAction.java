package action;

import com.opensymphony.xwork2.ActionSupport;

public class AboutDeveloperAction extends ActionSupport
{
	private static final long serialVersionUID = 6543007226612453176L;

	public String execute() throws Exception 
	{
		return SUCCESS;
	}
}
