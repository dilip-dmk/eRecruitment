package pojo;

public class ContactUsPojo 
{
	private String name;
	private Integer Contact_ID;
	private String Email;
	private String yourMessage;
	
	
	public Integer getContact_ID() {
		return Contact_ID;
	}
	public void setContact_ID(Integer contact_ID) {
		Contact_ID = contact_ID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getYourMessage() {
		return yourMessage;
	}
	public void setYourMessage(String yourMessage) {
		this.yourMessage = yourMessage;
	}
	
	
	

}
