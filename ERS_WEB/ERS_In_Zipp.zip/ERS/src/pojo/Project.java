/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pojo;

/**
 *
 * @author The Developer <Developer at APIIT>
 */
public class Project {
    Integer id;
    String name;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    

}
