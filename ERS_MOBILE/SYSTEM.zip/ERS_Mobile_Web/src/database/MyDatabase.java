package database;

import java.sql.Connection;
import java.sql.DriverManager;

public class MyDatabase 
{
	public MyDatabase() {
		
	}
	
	private static final String driverclass="com.ibm.db2.jcc.DB2Driver";
	static String url = "jdbc:db2://localhost:50000/ERS";
	static String userName="db2admin";
	static String Password="root";
	

    public Connection getDBConnection()
    {
    	Connection con=null;
    	try
    	{
    		 Class.forName(driverclass);
             con=DriverManager.getConnection(url,userName,Password);
             
       	}
    	catch (Exception e) {
			// TODO: handle exception
    		e.printStackTrace();
		}
    	
    	return con;
    }
    
   
}
