package dao;
import database.MyDatabase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class mobiledao 
{
	MyDatabase mydb=new MyDatabase();
	Connection con;
	ResultSet rs=null;
	PreparedStatement ptmt=null;
	
	public mobiledao() {
		con=mydb.getDBConnection();
		
	}
	
	public boolean checkUser(String EMAIL, String PASS)
	{
		System.out.println(EMAIL +"AND AGAIN"+PASS);
		try {
			
			
			
			String sql="SELECT * FROM DB2ADMIN.USERPOJO WHERE EMAIL=? AND PASSWORD=?";
			ptmt=con.prepareStatement(sql);
			ptmt.setString(1, EMAIL);
			ptmt.setString(2, PASS);
			rs=ptmt.executeQuery();
			if(rs.next())
			{
				return true;
			}
			else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	
	public String getJobInformation(String jobTitle,String jobSkill)
	{
		String result=null;
		String sql="SELECT * FROM DB2ADMIN.JOB_INFO WHERE TITLE LIKE %?% OR SKILL_REQ LIKE %?%";
		try {
			ptmt=con.prepareStatement(sql);
			ptmt.setString(1, jobTitle);
			ptmt.setString(2, jobSkill);
			rs=ptmt.executeQuery();
			if(rs.next())
			{
				String Title=rs.getString("TITLE");
				String Description=rs.getString(2);
				String EXPIRE_DATE=rs.getString(6);
				String JobRole=rs.getString("JOB_ROLE");
				String JobCat=rs.getString("JOB_CAT");
				
				result="Title: "+Title+"\t Description: "+Description+"\t Expiry Date: "+EXPIRE_DATE+" \tJob Role: "+JobRole+"\t Job Category"+JobCat;
						
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

}
