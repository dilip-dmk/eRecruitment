package servlets;
import dao.mobiledao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet 
{
	mobiledao dao=new mobiledao();
    HttpSession session;
    private String email;
    private String Password;
    private String method;
    private String jobTitle;
    private String jobSkill;
    String result=null;
    
    public LoginServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	//	processRequest(request, response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		session=request.getSession(true);
		
		email=request.getParameter("EMAIL");
		Password=request.getParameter("PASSWORD");
		method=request.getParameter("METHOD");
		System.out.println(email+"AND"+Password+"AND method="+method );
		
		if(method.equalsIgnoreCase("login"))
		{
			login(request,response);
		}
		else if(method.equalsIgnoreCase("searchJob"))
		{
			searchJob(request,response);
		}
		
		
		session.setAttribute("emailID", email);
	}

	protected void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{boolean b = false;
	email=request.getParameter("EMAIL");
	Password=request.getParameter("PASSWORD");
	System.out.println(email+"AND"+Password);
		PrintWriter out=response.getWriter();
		if(email!="" && Password!="")
		{
			
		 b=dao.checkUser(email,Password);
			if(b)
			{
				response.setContentType("text/plain");
			}
		}
		
		out.print(""+b);
		out.flush();
		out.close();
	}
	
	protected void searchJob(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		jobTitle=request.getParameter("JOBTITLE");
		jobSkill=request.getParameter("JOBSKILL");
		if(jobTitle!="" && jobSkill!="")
		{
			result=new mobiledao().getJobInformation(jobTitle,jobSkill);
		}
		response.setContentType("text/plain");
		PrintWriter out = response.getWriter();
		out.println(result);
		out.flush();
		out.close();
	}
	
	
}
